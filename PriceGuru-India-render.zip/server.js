// PriceGuru India - zero-dependency server (Node 18+). Run: node server.js
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC = path.join(__dirname, "public");

// ---- tiny .env loader (no dotenv needed) ----
try {
  const envFile = path.join(__dirname, ".env");
  if (fs.existsSync(envFile)) {
    for (const line of fs.readFileSync(envFile, "utf8").split(/\r?\n/)) {
      const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
      if (m && !line.trim().startsWith("#") && process.env[m[1]] === undefined) {
        process.env[m[1]] = m[2].replace(/^['"]|['"]$/g, "");
      }
    }
  }
} catch (e) { console.warn("Could not read .env:", e.message); }

const PORT = Number(process.env.PORT) || 3000;
const HOST = process.env.HOST || "0.0.0.0";
const SERP_URL = process.env.SERPAPI_URL || "https://serpapi.com/search.json";

const PLATFORMS = [
  ["Amazon.in","amazon.in"],["Flipkart","flipkart.com"],["Croma","croma.com"],
  ["Reliance Digital","reliancedigital.in"],["Vijay Sales","vijaysales.com"],
  ["Tata Cliq","tatacliq.com"],["JioMart","jiomart.com"],["Lotus Electronics","lotuselectronics.com"],
  ["Zepto","zeptonow.com"],["Blinkit","blinkit.com"],["Swiggy Instamart","swiggy.com"],
  ["BigBasket","bigbasket.com"]
];

const MIME = {".html":"text/html; charset=utf-8",".js":"text/javascript",".css":"text/css",
  ".json":"application/json",".png":"image/png",".jpg":"image/jpeg",".svg":"image/svg+xml",".ico":"image/x-icon"};

// Only trust prices that carry a currency marker; never grab random numbers like "128GB".
function parsePrice(v) {
  if (v == null) return null;
  if (typeof v === "number") return v >= 500 ? v : null;
  const m = String(v).match(/(?:₹|Rs\.?|INR)\s*([\d,]+(?:\.\d+)?)/i);
  if (!m) return null;
  const n = Number(m[1].replace(/,/g, ""));
  return Number.isFinite(n) && n >= 500 && n <= 5000000 ? Math.round(n) : null;
}

function extractPrice(item) {
  const ext = [item.rich_snippet?.top?.detected_extensions?.price,
               item.rich_snippet?.bottom?.detected_extensions?.price];
  for (const c of [item.price, ...ext]) { const p = parsePrice(c); if (p) return p; }
  return parsePrice(item.snippet);
}

function classify(text = "") {
  const t = text.toLowerCase();
  if (/out of stock|currently unavailable|sold out/.test(t)) return "Out of Stock";
  if (/in stock|buy now|add to cart/.test(t)) return "In Stock";
  return "Verify on site";
}

async function serpSearch(q, key) {
  const u = new URL(SERP_URL);
  u.searchParams.set("engine", "google");
  u.searchParams.set("q", q);
  u.searchParams.set("gl", "in");
  u.searchParams.set("hl", "en");
  u.searchParams.set("api_key", key);
  const r = await fetch(u, { signal: AbortSignal.timeout(20000) });
  const data = await r.json().catch(() => ({}));
  if (!r.ok || data.error) throw new Error(data.error || `Search provider returned ${r.status}`);
  return data;
}

async function checkPlatform([name, domain], model, key) {
  try {
    const data = await serpSearch(`${model} price site:${domain}`, key);
    const items = data.organic_results || [];
    const item = items.find(x => x.link?.includes(domain));
    if (!item) return { platform: name, status: "Not found", reason: "No result on this retailer", verified: false };
    const price = extractPrice(item);
    return {
      platform: name, title: item.title, link: item.link, price, currency: "INR",
      stock: classify(`${item.title} ${item.snippet || ""}`), snippet: item.snippet || "",
      rating: item.rich_snippet?.top?.detected_extensions?.rating ?? item.rating ?? null,
      verified: Boolean(price), checkedAt: new Date().toISOString()
    };
  } catch (e) {
    return { platform: name, status: "Error", reason: e.message, verified: false };
  }
}

// ---- cache + rate limit (protects your SerpAPI credits) ----
const cache = new Map();            // key -> {t, data}
const CACHE_MS = 10 * 60 * 1000;
const hits = new Map();             // ip -> [timestamps]
function rateLimited(ip) {
  const now = Date.now(), arr = (hits.get(ip) || []).filter(t => now - t < 60000);
  arr.push(now); hits.set(ip, arr);
  return arr.length > 8;
}

async function handleSearch(body) {
  const { model, city, pincode } = body || {};
  if (!model || !city || !/^\d{6}$/.test(String(pincode || "")))
    return [400, { error: "Model, city and a valid 6-digit pincode are required" }];
  const key = process.env.SERPAPI_KEY;
  const ck = `${String(model).toLowerCase().trim()}|${pincode}`;
  const hit = cache.get(ck);
  if (hit && Date.now() - hit.t < CACHE_MS) return [200, { ...hit.data, cached: true }];

  let results;
  if (!key) {
    results = PLATFORMS.map(([platform]) => ({ platform, status: "Not checked",
      reason: "SERPAPI_KEY is not configured on the server", verified: false }));
  } else {
    results = await Promise.all(PLATFORMS.map(p => checkPlatform(p, String(model).slice(0, 120), key)));
  }
  const priced = results.filter(x => Number.isFinite(x.price)).sort((a, b) => a.price - b.price);
  const data = {
    model, city, pincode, checkedAt: new Date().toISOString(), results,
    cheapest: priced[0] || null, keyConfigured: Boolean(key),
    disclaimer: "Search results are live web results, but checkout price, bank offers and pincode delivery must be verified on the retailer page."
  };
  if (key && priced.length) cache.set(ck, { t: Date.now(), data });
  return [200, data];
}

function send(res, code, obj, extra = {}) {
  const body = typeof obj === "string" ? obj : JSON.stringify(obj);
  res.writeHead(code, { "Content-Type": "application/json", ...extra });
  res.end(body);
}

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type"
};

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, "http://x");
    if (req.method === "OPTIONS") { res.writeHead(204, CORS); return res.end(); }

    if (url.pathname === "/api/health")
      return send(res, 200, { ok: true, keyConfigured: Boolean(process.env.SERPAPI_KEY) }, CORS);

    if (url.pathname === "/api/search" && req.method === "POST") {
      const ip = req.headers["x-forwarded-for"]?.split(",")[0].trim() || req.socket.remoteAddress;
      if (rateLimited(ip)) return send(res, 429, { error: "Too many searches. Wait a minute and retry." }, CORS);
      let raw = "";
      for await (const chunk of req) { raw += chunk; if (raw.length > 10000) return send(res, 413, { error: "Body too large" }, CORS); }
      let body; try { body = JSON.parse(raw || "{}"); } catch { return send(res, 400, { error: "Invalid JSON" }, CORS); }
      const [code, data] = await handleSearch(body);
      return send(res, code, data, CORS);
    }

    // static files, SPA fallback to index.html
    let file = path.normalize(path.join(PUBLIC, decodeURIComponent(url.pathname)));
    if (!file.startsWith(PUBLIC)) { res.writeHead(403); return res.end("Forbidden"); }
    if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) file = path.join(PUBLIC, "index.html");
    res.writeHead(200, { "Content-Type": MIME[path.extname(file)] || "application/octet-stream" });
    fs.createReadStream(file).pipe(res);
  } catch (e) {
    console.error(e);
    if (!res.headersSent) send(res, 500, { error: e.message }, CORS);
  }
});

server.listen(PORT, HOST, () => {
  console.log(`PriceGuru running on http://localhost:${PORT}`);
  if (!process.env.SERPAPI_KEY) console.warn("⚠ SERPAPI_KEY not set - searches will show 'Not checked'. Add it to .env");
});
