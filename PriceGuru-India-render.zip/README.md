# PriceGuru India

Mobile price-comparison web app. **Zero dependencies** - no `npm install` needed.

## Run (local)
1. Install Node.js 18+ (20/22 recommended).
2. Copy `.env.example` to `.env` and put your `SERPAPI_KEY` (https://serpapi.com).
3. `node server.js`  (or `npm start`)
4. Open http://localhost:3000

Without a key the app still opens; it shows "Not checked" (it never invents prices).

## Let anyone use it
The server listens on 0.0.0.0 and has CORS enabled, so any device on your Wi-Fi can open
`http://<your-pc-ip>:3000`. For a public link, deploy to Render / Railway / Fly.io:
Start command `node server.js`, add env var `SERPAPI_KEY`. No build step.

## API
- `POST /api/search`  body `{"model","city","pincode"}` -> JSON results
- `GET /api/health`

Built-in protections for your SerpAPI credits: 10-min result cache, 8 searches/min per IP.
